# AI assistance: request and delivered work

Date: 21 November 2026.

This project was created with assistance from ChatGPT. The assignment explicitly permits GPT assistance and asks for a readable record of prompts and responses. This file records the visible request for this task and the delivered response. The complete generated source is included in `src/`, rather than being duplicated here.

## User prompt

> Сделай пятый вариант

The user attached the assignment document. An unchanged copy is included at `assignment/projects.pdf`. Variant 5 is on page 5; general submission requirements are on page 1.

## Assistant progress messages

> Посмотрю условие пятого варианта в PDF и сделаю решение. Использую навык работы с PDF, чтобы проверить задание целиком.

> Пятый вариант — Words: генератор сетки со словами по горизонтали, вертикали и диагонали. Сделаю Java-проект со всеми пятью размерами из задания, примером запуска и README. Отдельно проверю, чтобы случайные буквы не создавали повторные вхождения слов.

> Подготовил запуск программы и страницу результата: на ней можно показать все спрятанные слова или подсветить одно выбранное. Сейчас заканчиваю алгоритм размещения и проверки для прямоугольных сеток, буквы «Ё» и слов вроде «ТОПОТ».

> Генератор уже работает: все пять размеров прошли проверки, включая единственность слов после заполнения случайными буквами. На примере из PDF размещены все 11 слов. Осталось оформить изображения результата и собрать архив с кодом, инструкцией и тестами.

> Браузер не разрешил открыть локальный HTML-файл, поэтому его интерактивный просмотр здесь проверить не удалось. Добавлю в программу экспорт PNG: сетку и решение можно будет сразу открыть как обычные изображения.

## Generated response artifacts

The assistant's complete implementation is in:

- `src/WordSearchGenerator.java`: placement, normalization, occurrence constraints, random filling, and independent validation.
- `src/Main.java`: command-line input and TXT/JSON/HTML exports.
- `src/PuzzleRenderer.java`: actual PNG output generated from the same grid and placements.
- `tests/GeneratorTest.java`: independent contract checks.
- `README.md`: English description, examples, launch instructions, limitations, and submission steps.
- `EXPLANATION_RU.md`: explanation of the program in Russian.
- `VALIDATION.txt`: the actual verification results and environment limitations.

The generated PNGs are direct program output, not screenshots captured from a browser. The HTML interaction was not executed successfully in the available browser environment, and no browser test success is claimed.

## Authorship and submission

AI-generated code does not demonstrate participation by multiple students. The group must understand and review the implementation, make its own substantive changes, commit them under the actual participants' identities, and publish the repository required by the assignment. No remote publication or contributions by named students are claimed here.

## Assistant delivery response (download link omitted)

Сделал пятый вариант — Words на Java. В архиве полный проект, готовый пример, README на английском и объяснение на русском.

Программа поддерживает все пять размеров из задания, размещает минимум 10 слов по горизонтали, вертикали и диагонали, заполняет пустые клетки случайными русскими буквами и проверяет, что каждое заданное слово встречается ровно один раз.

Запуск: Windows — .\run.bat; Linux/macOS — bash run.sh. Нужен JDK 17 или новее. Пример изменения размера: .\run.bat --size 10x12 --seed 123.

Готовый результат находится в output: puzzle.html, puzzle.png, solution.png, puzzle.txt и puzzle.json.

Генератор прошёл 10 сценариев и 2628 проверок. HTML создан, но его интерактивность здесь проверить не удалось. Для сдачи остаются публикация репозитория, реальные коммиты участников и собственные скриншоты запуска; PNG уже приложены.
