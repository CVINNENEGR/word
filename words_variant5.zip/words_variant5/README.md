# Words: Russian Word Search Generator

A Java 17 implementation of **variant 5, “Words”** from [the assignment](assignment/projects.pdf). It places Russian words in a rectangular letter grid and fills the remaining cells with random Russian letters. The program exports text, JSON, HTML, and PNG result images. The HTML page includes controls for revealing an individual word and showing or hiding the complete solution.

## Assignment

The assignment asks for a word search with at least 10 words. Words run in straight lines horizontally, vertically, or diagonally; they may be read in either direction. Intersections are optional and may share a cell only when the letters agree. Every input word must occur exactly once in the completed grid.

The supported grid sizes are **10×10, 11×10, 10×11, 12×10, and 10×12**, written as **rows × columns**. A word must fit entirely along at least one permitted straight line. A diagonal contains at most `min(rows, columns)` cells; its geometric length is not a word-length limit.

The group submission also requires an English README, input and output examples, screenshots, a live demonstration with a discussion of limitations, and a repository on GitHub, GitFlic, or Bitbucket with real commits from each of the 2–3 participants. AI assistance must be documented. See [Submission and collaboration](#submission-and-collaboration) and [AI_USAGE.md](AI_USAGE.md).

## Requirements

- JDK 17 or newer, including the `jdk.compiler` and `java.desktop` modules, with `java` on `PATH`. The standard Java AWT/ImageIO APIs draw and save PNG exports without opening a desktop window.
- The `javac` launcher on `PATH` if you use the manual compilation command below. The provided scripts can invoke the compiler through `java` when that launcher is unavailable.
- A UTF-8 text file containing the words.
- A browser to view the optional HTML result.

No Maven, Gradle, Gson, third-party Java libraries, or network connection is required to compile and run the program.

## Quick start

Run commands from the project directory.

### Linux or macOS

```sh
./run.sh
./run.sh --size 10x10 --seed 42 --words words.txt --out output
./test.sh
```

### Windows PowerShell

```powershell
.\run.bat
.\run.bat --size 10x10 --seed 42 --words words.txt --out output
.\test.bat
```

The run scripts compile the sources before launching the program. The shell scripts use `javac --release 17` when available. Their fallback, also used by the Windows scripts, is `java com.sun.tools.javac.Main -source 17 -target 17 -Xlint:-options`; it works in a JDK environment without a separate `javac` launcher or the `ct.sym` archive needed for `--release`. This fallback sets the language and bytecode versions; unlike `--release`, it does not restrict which platform APIs can be referenced. The sources use APIs available in Java 17. A runtime without the compiler module is insufficient. To compile and run directly with `javac`:

```sh
javac --release 17 -encoding UTF-8 -d build src/Main.java src/WordSearchGenerator.java src/PuzzleRenderer.java
java -cp build Main --size 10x10 --seed 42 --words words.txt --out output
java -cp build Main --help
```

The first command needs a **JDK**, not only a Java runtime.

## Command-line options

| Option | Default | Meaning |
| --- | --- | --- |
| `--size ROWSxCOLS` | `10x10` | One of the five supported grid sizes. |
| `--seed NUMBER` | `42` | Seed used for the randomized search and filler letters. |
| `--words PATH` | `words.txt` | UTF-8 input file with one word per line. |
| `--out DIRECTORY` | `output` | Directory for the generated result files. |
| `--help` | — | Print usage information. |

For a different layout, change the seed:

```sh
java -cp build Main --size 12x10 --seed 123 --words words.txt --out output-large
```

The same ordered input, settings, seed, and program version reproduce the same result. A seed is a way to reproduce an experiment; it does not guarantee that every difficult input will be solved within the search budget.

## Input format and validation

Each nonempty line contains one word. Blank lines and comment lines starting with `#` are ignored by the command-line reader.

Example input:

```text
# One Russian word per line
май
жена
шляпа
пояс
кухня
ковер
бровь
директор
слово
март
учитель
```

The generator normalizes words to Unicode NFC and uppercase before checking them. `Ё` is a separate letter from `Е`: for example, `ЕЛКА` and `ЁЛКА` are different words. Both uppercase and lowercase Russian input are accepted.

The following conditions are required:

- At least **10 distinct words** after normalization.
- At least **2 letters** in each word.
- Russian letters only: `А–Я` and `Ё` after normalization.
- No repeated normalized words. For example, `кот` and `КОТ` are a duplicate and are rejected.
- Every word must fit within the selected grid along a permitted direction.

Latin letters, numbers, punctuation, and spaces inside words are invalid. The program checks character validity and placement constraints; it does not consult a dictionary to decide whether a sequence of Russian letters is a real word.

The generator either returns a complete valid puzzle containing **all** input words, or reports an error. It does not silently remove words to obtain a result.

## Output

With `--out output`, a successful run creates:

| File | Contents |
| --- | --- |
| [output/puzzle.txt](output/puzzle.txt) | A readable text grid and the solution information. |
| [output/puzzle.json](output/puzzle.json) | The grid, generation settings, and the coordinates needed to read the words. |
| [output/puzzle.html](output/puzzle.html) | A self-contained browser view with a show/hide solution button. |
| [output/puzzle.png](output/puzzle.png) | A PNG export of the puzzle, drawn directly from the generated data. |
| [output/solution.png](output/solution.png) | A PNG export of the same puzzle with the solution highlighted. |

Open `output/puzzle.html` directly in a browser; a web server is not needed. Its controls are designed to highlight an individual word and to show or hide all answers. A subsequent run with the same output directory replaces these five generated files.

**Browser verification:** interactive browser checks were unavailable in the preparation environment. Before presenting the project, open the HTML page locally and check its controls. See [VALIDATION.txt](VALIDATION.txt) for the actual completed checks and remaining limitation.

**Coordinate conventions:** JSON uses **zero-based** row and column indexes. The console presents coordinates as **one-based** values for readers. Coordinates follow the letters of the word in reading order; a word may travel toward decreasing row or column indexes.

The JSON root contains `rows`, `columns`, `seed`, `coordinateBase`, `grid`, and `words`. Each string in `grid` is one complete row. Each word object contains `text`, its start cell (`row`, `col`), direction (`dr`, `dc`), and end cell (`endRow`, `endCol`). For letter index `i`, its cell is `(row + i * dr, col + i * dc)`. This compact representation specifies every letter's coordinates without repeating the full coordinate list.

### Reproducible example

The bundled input above was run with:

```sh
./run.sh --size 10x10 --seed 42 --words words.txt --out output
```

The resulting **10×10 grid contains all 11 words**:

```text
А Ч Ь Ь О Ф Г Й У Й
П О В О Л С Я О П Э
Я Р О Т К Е Р И Д Х
Л Ч Р Й У О Т Ь О Ч
Ш А Б Ю Х Ъ В И Ж М
М Т Й П Н Х Ъ Е Ч Ш
З Ц Т Х Я М Н Й Р У
Ф Ё Ч Н А А Н П Л К
Ч Ф Г К Ё Й Б З У Ж
Т П Э Р З Ё Я В Щ Я
```

For example, the text solution reports `МАЙ: (7, 6) -> (9, 6), вниз`. The corresponding object in `output/puzzle.json` is:

```json
{"text": "МАЙ", "row": 6, "col": 5, "dr": 1, "dc": 0, "endRow": 8, "endCol": 5}
```

The difference of one in the coordinate values is intentional. The complete text and JSON outputs are linked above.

### Result images

These are **real PNG exports generated by `PuzzleRenderer.java` using Java AWT and ImageIO**. They are not screenshots of a browser. For strict compliance with the assignment's screenshot requirement, capture your own browser screenshots when you verify and demonstrate the HTML result.

Puzzle view:

![PNG export of the generated word search without highlighted answers](output/puzzle.png)

Solution view:

![PNG export of the same word search with its solution highlighted](output/solution.png)

## What “exactly once” means

Uniqueness is checked against the **finished letters**, not just against the list of deliberately placed words. A second occurrence accidentally created by intersections or filler letters would make the puzzle invalid.

Every word is searched in all eight directions:

| Direction | Row change | Column change |
| --- | ---: | ---: |
| Right | 0 | +1 |
| Left | 0 | −1 |
| Down | +1 | 0 |
| Up | −1 | 0 |
| Down-right | +1 | +1 |
| Down-left | +1 | −1 |
| Up-right | −1 | +1 |
| Up-left | −1 | −1 |

A palindrome read forward and backward along the **same physical segment** counts as one occurrence. Two different segments count as two occurrences.

If a requested word is already present as part of another placed word, that existing segment can serve as its single occurrence. The generator must not add an unnecessary second copy. For example, when both `ЛЕС` and `ЛЕСТНИЦА` are requested, the `ЛЕС` segment inside `ЛЕСТНИЦА` can satisfy the shorter word. Its coordinates still appear in the solution.

The program only enforces this rule for the requested words. Other unintended letter sequences, including unrequested dictionary words, may appear.

## Algorithm

1. Normalize and validate the input and the selected grid size.
2. Precompute possible straight word segments, called windows. Search for placements using randomized backtracking, choosing the longest word that has no occurrence yet. Reject candidates that disagree with letters already present. Prefer an orientation family not used yet, then candidates that reuse more existing letters; randomized ordering breaks ties.
3. Reuse an existing unique occurrence when it already satisfies a requested word. Update window counters only for windows touching a changed cell; reject a move as soon as a word gets a second physical occurrence.
4. If a choice prevents a valid completion, undo that choice and try another candidate. At least one horizontal, one vertical, and one diagonal placement must appear in a returned puzzle.
5. Fill unused cells by choosing the cell with the fewest allowed letters first. For a matching word window with one cell left, forbid the letter that would complete a duplicate. Try the remaining letters in randomized order, backtrack when needed, and independently verify the completed grid.
6. Export the result only after a complete valid puzzle is obtained.

The seed controls randomized choices. Backtracking separates this implementation from a one-pass placement loop: a failed later choice can cause earlier choices to be reconsidered.

Search is capped at **16 attempts** and **200,000 total search steps**. Each attempt allows at most **12,000 placement steps** and **30,000 filling steps**, within the shared total. A step is a tried placement or filler letter, not a time interval. These constants are defined in `WordSearchGenerator.java`; they are not command-line options.

The Russian walkthrough in [EXPLANATION_RU.md](EXPLANATION_RU.md) explains the approach and suggests a short classroom demonstration.

## Tests

```sh
./test.sh
```

On Windows:

```powershell
.\test.bat
```

The test entry point is [tests/GeneratorTest.java](tests/GeneratorTest.java). It runs without a testing framework. It checks all five grid sizes, seed reproducibility, normalization and `Ё`, palindromes, shared subwords, word-length limits, invalid input, and detection of a damaged grid. An independent scanner checks the completed letters in all eight directions instead of trusting the generator's placement metadata. The source is the authoritative list of implemented checks; the console reports the result of the actual test run.

For a classroom demonstration, also try a duplicate word, a Latin letter, fewer than 10 words, an overlong word, and a different seed. An invalid input should produce a useful error rather than an incomplete puzzle.

A ready-made rejection example contains only nine words:

```sh
./run.sh --words examples/too_few_words.txt
```

The application reports the validation error and exits with a nonzero status. On Windows, use `.\run.bat --words examples/too_few_words.txt`.

## Project files

| Path | Purpose |
| --- | --- |
| `src/Main.java` | Command-line parsing, reading the word file, and writing the output formats. |
| `src/WordSearchGenerator.java` | Input normalization, randomized placement search, and occurrence validation. |
| `src/PuzzleRenderer.java` | Drawing puzzle and solution PNG exports with standard Java AWT/ImageIO. |
| `tests/GeneratorTest.java` | Standalone algorithm tests. |
| `words.txt` | Bundled sample input. |
| `examples/too_few_words.txt` | Invalid input for demonstrating the minimum word count. |
| `assignment/projects.pdf` | Original assignment, including variant 5 and group submission rules. |
| `run.sh`, `run.bat` | Compile and run the application. |
| `test.sh`, `test.bat` | Compile and run the tests. |
| `output/` | Generated sample text, JSON, HTML, and two PNG exports. |
| `EXPLANATION_RU.md` | Explanation and demonstration guide in Russian. |
| `VALIDATION.txt` | Actual verification results and the remaining browser-check limitation. |
| `AI_USAGE.md` | Record of AI assistance; keep the actual prompts and responses with the submission. |

## Limitations and weak points

- **Bounded search.** Placement is a constraint problem. The search can reach its budget even when a solution exists. A failure within the budget is not a mathematical proof that the input is impossible. Try a different seed, a larger permitted size, or a less constrained word list.
- **Difficult inputs.** Dense lists, long words, many shared fragments, and short words that easily appear by accident can require much more search than the bundled sample. Some sets are genuinely incompatible with the exactly-once rule.
- **Additional orientation condition.** The implementation requires all three orientation families to appear. A list whose words fit only horizontally, for example, cannot satisfy that condition even when every individual word fits the board.
- **Preprocessing and memory.** Possible word windows are stored before search. Very large word lists consume more memory and preparation time. The search-step budget does not impose a wall-clock timeout or a separate preprocessing limit.
- **Fixed scope.** Only the five assignment sizes and Russian-letter words are supported. This version does not implement arbitrary grid sizes, a dictionary service, difficulty scoring, or interactive tracing and checking of answers.
- **Validation is not linguistic.** The generator accepts a valid sequence of Russian letters even if it has no dictionary meaning.
- **Unrequested sequences.** Random filling can produce words that were not requested. Only the requested list is checked for exactly one occurrence.
- **Visible answer data.** The HTML view contains the solution in the file. Hiding the highlights does not make the answer secret.
- **Reproducibility scope.** A changed algorithm or changed word order can change the result even with the same seed.

## Submission and collaboration

This project folder does not by itself prove that a remote repository has been published or that a group has contributed. Before submission:

1. Create a repository on **GitHub, GitFlic, or Bitbucket** and push the project to its actual remote URL.
2. Work in a group of **2–3 real participants**. Each participant should make meaningful changes and commit them using their own identity. Do not fabricate authors or create cosmetic commits to imitate participation.
3. Divide substantive work, for example: placement and validation; CLI and export; tests and documentation. The actual division should match the work performed.
4. Keep the English README and working input/output examples in the repository. Open the HTML result on your computer, check its controls, and capture actual browser screenshots for the assignment. The bundled PNG exports are result images, not a claim that browser screenshots were obtained.
5. Preserve the readable record of AI prompts and responses required by the assignment. [AI_USAGE.md](AI_USAGE.md) should explain the assistance actually used; a general disclosure alone does not replace the requested transcript.
6. Rehearse a clean checkout, compilation, generation, opening the HTML result, running the tests, and demonstrating a limitation.

The implementation uses randomized backtracking, physical-occurrence checking, and validation after filling. These are concrete design choices that participants should be able to explain. The code of competing groups is unknown, so **global uniqueness against other submissions cannot be guaranteed**. If comparison becomes possible, assess the algorithm and structure rather than merely renaming classes or files.
